import * as c from '../lib/lib.js'
function PageInit(){
    // code here
}
PageInit()